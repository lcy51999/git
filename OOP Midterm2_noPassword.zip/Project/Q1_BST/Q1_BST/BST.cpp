#include "BST.h"
#include<iostream>
#include<queue>
using namespace std;

void BST::insert(Node* insertNode) {
    //TODO: insert a node to BST
}

void BST::InOrder_traversal(Node* node){
    //TODO: Inorder traversal
}

void BST::PreOrder_traversal(Node* node){
    //TODO: PreOrder traversal
}

void BST::PostOrder_traversal(Node* node){
    //TODO: PostOrder traversal
}

void BST::LevelOrder_traversal(Node* node){
    //TODO: Level order traversal
}

int BST::ComputeHeight(Node* node){
    // Compute the height of the binary search tree.
    // Notice that the root level is 1
}

Node* BST::getRoot() {
    //TODO: return root of BST
    return this->root;
}