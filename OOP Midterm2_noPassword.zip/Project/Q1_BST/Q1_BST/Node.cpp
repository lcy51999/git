#include "Node.h"
int Node::getValue() {
	// TODO: return the value of node
}

Node* Node::getLchild() {
	// TODO: return the left child of this node
}
Node* Node::getRchild() {
	// TODO: return the right child of this node
}

void Node::setLchild(Node* node) {
	// TODO: set the left child of this node
}
void Node::setRchild(Node* node) {
	// TODO: set the right child of this node
}